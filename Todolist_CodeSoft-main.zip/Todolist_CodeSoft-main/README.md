# todolist

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.

# Output
<img src="https://github.com/Abhisheknik/Todolist/assets/79035081/95b19729-332f-45e2-95b1-af8cbc4e3ff6" alt="Screenshot 1" width="400" height="600">
<img src="https://github.com/Abhisheknik/Todolist/assets/79035081/f880e41a-3815-4654-9bd0-8428f373eb57" alt="Screenshot 2" width="400" height="600">
