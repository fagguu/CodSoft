/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.best.deskclock.data;

/**
 * A read-only domain object representing a stopwatch lap.
 */
public final class Lap {

    /**
     * The 1-based position of the lap.
     */
    private final int mLapNumber;

    /**
     * Elapsed time in ms since the lap was last started.
     */
    private final long mLapTime;

    /**
     * Elapsed time in ms accumulated for all laps up to and including this one.
     */
    private final long mAccumulatedTime;

    Lap(int lapNumber, long lapTime, long accumulatedTime) {
        mLapNumber = lapNumber;
        mLapTime = lapTime;
        mAccumulatedTime = accumulatedTime;
    }

    public int getLapNumber() {
        return mLapNumber;
    }

    public long getLapTime() {
        return mLapTime;
    }

    public long getAccumulatedTime() {
        return mAccumulatedTime;
    }
}
